import random
fi = open('insults.txt')
insults=[]
for line in fi:
    insults.append(line)
    
def lambda_handler(event,context):
    end = True
    if(event['request']['type'] == "IntentRequest" and event['request']['intent']['name'] == "AMAZON.HelpIntent"):
        ins = "Just ask alexa to roast you!"
        end = False
    elif(event['request']['type'] == "IntentRequest" and event['request']['intent']['name'] == "AMAZON.StopIntent" or event['request']['intent']['name'] == "AMAZON.CancelIntent"):
        ins = "Thanks for getting roasted, hope we never see you again!"
    else:
        ins = random.choice(insults) 
    test = {}
    test['version'] = 1.0
    test['response'] = {"outputSpeech": { "type" :"PlainText","text":ins},"shouldEndSession" :end}
    return test

